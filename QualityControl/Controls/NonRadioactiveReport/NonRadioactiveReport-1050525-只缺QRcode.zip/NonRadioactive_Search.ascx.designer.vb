﻿'------------------------------------------------------------------------------
' <自動產生的>
'     這段程式碼是由工具產生的。
'
'     對這個檔案所做的變更可能會造成錯誤的行為，而且如果重新產生程式碼，
'     所做的變更將會遺失。 
' </自動產生的>
'------------------------------------------------------------------------------

Option Strict On
Option Explicit On


Partial Public Class NonRadioactive_Search

    '''<summary>
    '''ckBydate 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents ckBydate As Global.System.Web.UI.WebControls.CheckBox

    '''<summary>
    '''tbDateS 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents tbDateS As Global.System.Web.UI.WebControls.TextBox

    '''<summary>
    '''CalendarExtender1 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents CalendarExtender1 As Global.AjaxControlToolkit.CalendarExtender

    '''<summary>
    '''tbDateE 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents tbDateE As Global.System.Web.UI.WebControls.TextBox

    '''<summary>
    '''CalendarExtender2 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents CalendarExtender2 As Global.AjaxControlToolkit.CalendarExtender

    '''<summary>
    '''tbLabno 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents tbLabno As Global.System.Web.UI.WebControls.TextBox

    '''<summary>
    '''tbBuyer 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents tbBuyer As Global.System.Web.UI.WebControls.TextBox

    '''<summary>
    '''tbCoilno 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents tbCoilno As Global.System.Web.UI.WebControls.TextBox

    '''<summary>
    '''btnAdd 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents btnAdd As Global.System.Web.UI.WebControls.Button

    '''<summary>
    '''btnSearch 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents btnSearch As Global.System.Web.UI.WebControls.Button

    '''<summary>
    '''lbMessage 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents lbMessage As Global.System.Web.UI.WebControls.Label

    '''<summary>
    '''ListView1 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents ListView1 As Global.System.Web.UI.WebControls.ListView

    '''<summary>
    '''ods 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents ods As Global.System.Web.UI.WebControls.ObjectDataSource

    '''<summary>
    '''CustomValidator1 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents CustomValidator1 As Global.System.Web.UI.WebControls.CustomValidator

    '''<summary>
    '''hfSQL 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents hfSQL As Global.System.Web.UI.WebControls.HiddenField
End Class
