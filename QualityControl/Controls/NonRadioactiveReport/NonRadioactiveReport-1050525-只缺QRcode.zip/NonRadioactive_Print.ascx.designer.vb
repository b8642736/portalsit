﻿'------------------------------------------------------------------------------
' <自動產生的>
'     這段程式碼是由工具產生的。
'
'     對這個檔案所做的變更可能會造成錯誤的行為，而且如果重新產生程式碼，
'     所做的變更將會遺失。 
' </自動產生的>
'------------------------------------------------------------------------------

Option Strict On
Option Explicit On


Partial Public Class NonRadioactive_Print

    '''<summary>
    '''ReportViewer1 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents ReportViewer1 As Global.Microsoft.Reporting.WebForms.ReportViewer

    '''<summary>
    '''ObjectDataSource1 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents ObjectDataSource1 As Global.System.Web.UI.WebControls.ObjectDataSource

    '''<summary>
    '''Label1 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents Label1 As Global.System.Web.UI.WebControls.Label

    '''<summary>
    '''tbLabNo 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents tbLabNo As Global.System.Web.UI.WebControls.TextBox

    '''<summary>
    '''tb_subno 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents tb_subno As Global.System.Web.UI.WebControls.TextBox

    '''<summary>
    '''btnPrint 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents btnPrint As Global.System.Web.UI.WebControls.Button

    '''<summary>
    '''CustomValidator1 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents CustomValidator1 As Global.System.Web.UI.WebControls.CustomValidator

    '''<summary>
    '''Label2 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents Label2 As Global.System.Web.UI.WebControls.Label

    '''<summary>
    '''ddLangCode 控制項。
    '''</summary>
    '''<remarks>
    '''自動產生的欄位。
    '''將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    '''</remarks>
    Protected WithEvents ddLangCode As Global.System.Web.UI.WebControls.DropDownList
End Class
