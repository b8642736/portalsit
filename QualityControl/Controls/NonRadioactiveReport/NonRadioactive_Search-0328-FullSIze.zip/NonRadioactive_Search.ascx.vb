﻿Public Class NonRadioactive_Search
    Inherits System.Web.UI.UserControl
    Public Event Event_reFresh父物件(ByVal from主畫面_ActiveTabIndex As NonRadioactive_Main.主畫面_Enum, _
                           ByVal fromLabno As String)

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then
            MakeQryStringToControl()
        End If
    End Sub

#Region "產生查詢字串至控制項  函式:MakeQryStringToControl"
    Private Sub MakeQryStringToControl()

        Dim querySql As New StringBuilder
        querySql.Append("SELECT * FROM LabRecordA1_M WHERE 1=1 " & vbNewLine)
        If tbStartDate.Text.Length > 0 And tbEndDate.Text.Length > 0 Then
            querySql.Append("and 資料日期 between '" & tbStartDate.Text & "' and '" & tbEndDate.Text & "'")
        End If
        querySql.Append("order by LAB_REPORTNO DESC" & vbNewLine)
        Me.hfSQL.Value = querySql.ToString
    End Sub
#End Region

#Region "SystemNote:CRUD"
    <DataObjectMethod(DataObjectMethodType.Select)>
    Public Function Search(ByVal fromSQL As String) As List(Of SQLServer.QCdb01.LabRecordA1_M)
        If String.IsNullOrEmpty(fromSQL) Or fromSQL = "" Then
            Return New List(Of SQLServer.QCdb01.LabRecordA1_M)
        End If
        Return SQLServer.QCdb01.LabRecordA1_M.CDBSelect(Of SQLServer.QCdb01.LabRecordA1_M)(SQLServerSQLQueryAdapter.ConnectionMoeEnum.ADO, fromSQL)
    End Function

    <DataObjectMethod(DataObjectMethodType.Insert)>
    Public Function Insert(ByVal fromObj As SQLServer.QCdb01.LabRecordA1_M) As Integer
        Try
            Return fromObj.CDBInsert
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.OkOnly, "系統資訊")
        End Try
    End Function

    <DataObjectMethod(DataObjectMethodType.Update)>
    Public Function Update(ByVal fromObj As SQLServer.QCdb01.LabRecordA1_M) As Integer
        Return fromObj.CDBUpdate
    End Function

    <DataObjectMethod(DataObjectMethodType.Delete)>
    Public Function Delete(ByVal fromObj As SQLServer.QCdb01.LabRecordA1_M) As Integer
        Return fromObj.CDBDelete
    End Function
#End Region
    Public Sub P_reFresh子物件()
        MakeQryStringToControl()
        ListView1.DataBind()
    End Sub
    Protected Sub btnPrint_Click(sender As Object, e As EventArgs)
        Dim labno As String = CType(sender, Button).ToolTip.Trim
        RaiseEvent Event_reFresh父物件(NonRadioactive_Main.主畫面_Enum.列印, labno)
    End Sub
    Private Sub ListView1_PreRender(sender As Object, e As EventArgs) Handles ListView1.PreRender
        'Dim listViewIetem As ListViewItem = Nothing

        'Dim txtObj As TextBox = Nothing
        'Dim ddObj As DropDownList = Nothing

        'If Not ListView1.EditItem Is Nothing Then

        '    listViewIetem = ListView1.EditItem

        '    txtObj = CType(listViewIetem.FindControl("標題1TextBox"), TextBox)
        '    ddObj = CType(listViewIetem.FindControl("標題1DropDownList1"), DropDownList)

        '    'For Each eahcItem As ListItem In ddObj.Items
        '    '    If eahcItem.Text.Equals(txtObj.Text) Then
        '    '        eahcItem()
        '    '        Exit For
        '    '    End If
        '    'Next
        'End If

    End Sub
    Public Function FS_partStr(str As String, len As Int32)
        If str.Length > len Then
            Return str.Substring(0, len) & " ..."
        End If
        Return str
    End Function
    Private Sub ListView1_ItemUpdating(sender As Object, e As ListViewUpdateEventArgs) Handles ListView1.ItemUpdating
        e.NewValues("品檢日期_起") = Date.Parse(e.NewValues("品檢日期_起"))
        e.NewValues("品檢日期_迄") = Date.Parse(e.NewValues("品檢日期_迄"))
        e.NewValues("資料日期") = Date.Parse(e.NewValues("資料日期"))
    End Sub

    Private Sub ListView1_ItemUpdating(sender As Object, e As ListViewInsertEventArgs) Handles ListView1.ItemInserting
        e.Values("品檢日期_起") = Date.Parse(e.Values("品檢日期_起"))
        e.Values("品檢日期_迄") = Date.Parse(e.Values("品檢日期_迄"))
        e.Values("資料日期") = Date.Parse(e.Values("資料日期"))
    End Sub

    Protected Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        lbMessage.Text = ""
        Try
            Date.Parse(tbStartDate.Text)
            Date.Parse(tbEndDate.Text)
        Catch ex As Exception
            lbMessage.Text = "Error：請輸入正確時間格式"
            Exit Sub
        End Try
        MakeQryStringToControl()
    End Sub
    
End Class